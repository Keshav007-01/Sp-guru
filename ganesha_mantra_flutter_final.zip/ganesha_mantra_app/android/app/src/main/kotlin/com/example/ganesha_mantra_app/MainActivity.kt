package com.example.ganesha_mantra_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {}
